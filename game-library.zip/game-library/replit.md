# LEVELUP — Game Library

## Overview
A client-side single-page web application for tracking a personal game library. No backend or build system — pure HTML, CSS, and JavaScript in a single file.

## Architecture
- **Type:** Static HTML/JS/CSS single-page app
- **Entry point:** `index.html`
- **Server:** Python's built-in HTTP server (`python3 -m http.server 5000 --bind 0.0.0.0`)
- **Port:** 5000

## Features
- Game library with add/edit/delete
- Platform filtering (Retroid Pocket 5, PS5, Nintendo Switch, Xbox Series X)
- Status tracking (Playing, Played, Backlog, Wishlist)
- Star ratings and notes
- Game art fetching via RAWG API
- Recommend tab for picking a random backlog game
- Persists data in browser localStorage

## External APIs
- **RAWG API** (`api.rawg.io`) — fetches game cover art using a hardcoded API key
- **corsproxy.io** — CORS proxy used for RAWG API requests

## Deployment
- Target: static
- Public directory: `.` (root)
